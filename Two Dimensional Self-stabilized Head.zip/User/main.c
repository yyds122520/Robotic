#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "MPU6050.h"
#include "Timer.h"
#include "IMU.h"
#include "PWM.h"
#include "Servo.h"

extern PARAM_ANGLE IMU_Angle;

void TIM3_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM3,TIM_IT_Update)==SET)
	{
		IMU_GetEulerAngles();
		Servo_SetAngle(-IMU_Angle.Yaw);
		TIM_ClearITPendingBit(TIM3,TIM_IT_Update);
	}
}

int main()
{
	OLED_Init();
	MPU6050_Init();
	Timer_Init();
	Servo_Init();
	
	OLED_ShowString(1,1,"Roll:");
	OLED_ShowString(2,1,"Pitch:");
	OLED_ShowString(3,1,"Yaw:");
	
	while(1)
	{
		OLED_ShowSignedNum(1,6,IMU_Angle.Roll,4);
		OLED_ShowSignedNum(2,7,IMU_Angle.Pitch,4);
		OLED_ShowSignedNum(3,5,IMU_Angle.Yaw,4);
	}
}
