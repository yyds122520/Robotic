#ifndef __MYIIC_H
#define __MYIIC_H

void MyIIC_Init(void);
void MyIIC_Start(void);
void MyIIC_Stop(void);
void MyIIC_SendByte(uint8_t Byte);
uint8_t MyIIC_ReceiveByte(void);
void MyIIC_SendAck(uint8_t AckBit);
uint8_t MyIIC_ReceiveAck(void);

#endif
