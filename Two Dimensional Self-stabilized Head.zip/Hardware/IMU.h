#ifndef __IMU_H
#define __IMU_H

#include "MPU6050.h"
#include <math.h>
#include "stm32f10x.h" 

typedef struct{
	float AX;
	float AY;
	float AZ;
	float GX;
	float GY;
	float GZ;
}PARAM_IMU;

typedef struct{
	float Roll;
	float Pitch;
	float Yaw;
}PARAM_ANGLE;

float fast_sqrt(float x);
void IMU_GetValues(void);
void IMU_AHRSupdate(PARAM_IMU *IMU_Temp);
void IMU_GetEulerAngles(void);

#endif
