#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"

int main()
{
	OLED_Init();
	
	OLED_ShowNum(1,1,202309090,9);
	OLED_ShowNum(1,10,5015,4);
	OLED_ShowString(2,1,"Yaotian Liu");
}
