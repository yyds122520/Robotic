#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Servo.h"

uint16_t a=60,b=60;
uint16_t min,max;

int main()
{
	Servo_Init();
	
	min=1499-(a*100/9);
	max=1499+(b*100/9);
	
	TIM_SetCompare2(TIM2,min);
	
	while(1)
	{
		TIM_SetCompare2(TIM2,max);
		Delay_ms(400);
		TIM_SetCompare2(TIM2,min);
		Delay_ms(400);
	}
}
